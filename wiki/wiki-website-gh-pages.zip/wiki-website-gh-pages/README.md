# Typora Wiki Website

<http://support.typora.io>

Knowledge base for Typora, as well as examples of using Typora with static site generators like Jekyll.

Jekyll theme forked from [jekyllthemes](https://github.com/mattvh/jekyllthemes/) and [jekyllDecent](https://github.com/jwillmer/jekyllDecent), MIT License.

For bugs and suggestions on Typora, please contact <hi@typora.io> or [typora-issues](https://github.com/typora/typora-issues/issues).
