---
layout: post
title: Launch Options
author: typora.io
category: how-to
tags: [launch, folder, project]
typora-root-url: ../
---

When typora is launched, you could set default actions to:

- Open new file
- Restore last closed folder
- Restore last closed file and folder
- Open a custom folder.

This option can be set in preferences panel:

<img src="/media/files/Screen Shot 2019-01-06 at 22.39.31.png" style="zoom:50%;" />

